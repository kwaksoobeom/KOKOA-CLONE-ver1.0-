/* ----------------------------------

>> 10월 16일 (일) 6.21 ~ 6.23

Find 창 3/4 완료!!

1) find.html 추가, screens에 find.css 추가 (참고로, chats.html 은 모두 components 였어서 따로 css 만들지 않음!)

2) 톱니바퀴 위에 주황점 추가

3) 동일하게 nav 꽉 채워지게 수정

4) 기존 chats의 class="main-screen" 을 비우고 안에 find-icons, recommended-friends, open-chat 을 만듦

5) 현재 find-icons, recommended-friends 까지 완성함. open-chat은 진행중.



+ 15일 카카오 화재로 접속 불가... 휴식..! 내일도 3개 목표로 해서 할당량 채우자!! 수고했어! :D
++ TLqkf 티스토리 요즘 왜 저래.. */